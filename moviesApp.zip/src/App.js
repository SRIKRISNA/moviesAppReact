import './App.css';
import Main from './components/main';
// import Card from './components/card';
// import SingleMovie from './components/singleMovie';
function App() {
  return (
    <div className="app-container">
      <Main/>
    </div>
  );
}

export default App;
